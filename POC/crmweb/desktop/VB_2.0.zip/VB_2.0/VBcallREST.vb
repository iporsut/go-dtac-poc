﻿Imports System
Imports System.Collections.Generic
Imports System.Collections
Imports System.Collections.Specialized
Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Configuration

Module QuickSharp

    dim public URL as string  = "http://pak-hp:8080/countries"
    dim public DATA as string = "{""Code"": ""EN"",""Name"": ""England""}"
    
    Sub Main(ByVal cmdArgs() As String)
        dim url as string 
        dim dat as string 
       
        url = Read_URL()
        dat = Read_Text_Data()
        if cmdArgs.Length > 0 then
            Console.WriteLine("argument data = {0}", cmdArgs)
            dat = cmdArgs(0)
            Console.WriteLine("dat = {0}", dat)
        end if 
        Console.WriteLine("Request URL={0}",url)
        Console.WriteLine("Request DATA={0}",dat)
        POST_REQ(url, dat)
        Console.WriteLine("====================================================")    
    End Sub

    public Sub POST_REQ(endpoint as string, data as string)
        try 
            dim myHttpWebRequest as HttpWebRequest = WebRequest.Create(endpoint)
            myHttpWebRequest.ContentType = "application/json"
            myHttpWebRequest.Method = "POST"
            dim encoding as UTF8Encoding  = new UTF8Encoding()
            dim byte1 as byte() = encoding.GetBytes(data)
            myHttpWebRequest.ContentLength = byte1.Length
            
            
            dim newStream as Stream = myHttpWebRequest.GetRequestStream()
            newStream.Write (byte1, 0, byte1.Length)
            'Console.WriteLine ("The value of 'ContentLength' property after sending the data is {0}", myHttpWebRequest.ContentLength)

            newStream.Close ()
            
            
            dim myHttpWebResponse as HttpWebResponse = myHttpWebRequest.GetResponse()
            
            Console.WriteLine("Response below")
            Console.WriteLine("====================================================")
            Console.WriteLine("StatusCode:{0}",myHttpWebResponse.StatusCode)
            Console.WriteLine("Status Description:{0}",myHttpWebResponse.StatusDescription)
            Console.WriteLine("Header : {0}" , myHttpWebResponse.Headers)

            dim sResponse as string
            dim stream as Stream = myHttpWebResponse.GetResponseStream()
            using stream
                dim reader as StreamReader  = new StreamReader(stream, System.Text.Encoding.UTF8)
                sResponse = reader.ReadToEnd()
            end using
            Console.WriteLine("{0}",sResponse)

            myHttpWebResponse.Close()
            
        catch e as WebException 
            Console.WriteLine("This program is expected to throw WebException on successful run.\n\nException Message :" + e.Message)
            if e.Status = WebExceptionStatus.ProtocolError then
                'Console.WriteLine("Status Code : {0}", ((HttpWebResponse)e.Response).StatusCode)
                'Console.WriteLine("Status Description : {0}", ((HttpWebResponse)e.Response).StatusDescription)
            end if
        catch e as Exception 
            Console.WriteLine(e.Message)
        end try         

    end sub
            
           
    private function Read_URL() as string
        dim config as System.Configuration.Configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None)
        
        dim setting = ConfigurationManager.AppSettings
        dim endpoint = setting("ENDPOINT")
        return endpoint.ToString()
    end function
            
    private function Read_Text_Data() as string
    
        dim line as String=""
        dim config as System.Configuration.Configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None)
        dim setting = ConfigurationManager.AppSettings
        dim filename = setting("DATA")
        try
            dim sr as StreamReader = new StreamReader(filename)
            line = sr.ReadToEnd()

        catch e as Exception
            Console.WriteLine("The file could not be read:")
            Console.WriteLine(e.Message)
        end try
        
        return line
    end function


End Module
